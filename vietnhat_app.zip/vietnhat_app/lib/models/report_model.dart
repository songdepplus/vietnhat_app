class ReportModel {
  final String title;
  final int value;

  ReportModel({required this.title, required this.value});
}

