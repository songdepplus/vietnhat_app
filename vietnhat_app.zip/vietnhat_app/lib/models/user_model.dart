class UserModel {
  final String username;
  final String role;

  UserModel({required this.username, required this.role});
}

